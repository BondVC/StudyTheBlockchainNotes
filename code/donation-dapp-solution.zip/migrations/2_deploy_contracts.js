var Donate = artifacts.require("Donate");

module.exports = function(deployer) {
  deployer.deploy(Donate);
};